﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

namespace PixelArtApp
{
    public partial class Form1 : Form
    {
        private bool _isDrawing = false;
        private string _currentTool = "Pencil";
        private Color _currentColor = Color.Black;
        private Point _previousPoint;
        private Bitmap _canvasBitmap;

        public Form1()
        {
            InitializeComponent();
            _canvasBitmap = new Bitmap(drawingPanel.Width, drawingPanel.Height);
            using (Graphics g = Graphics.FromImage(_canvasBitmap))
            {
                g.Clear(Color.White); // Clear the canvas with white color initially
            }
            drawingPanel.BackgroundImage = _canvasBitmap;
        }

        private void PencilButton_Click(object sender, EventArgs e)
        {
            _currentTool = "Pencil";
        }

        private void EraserButton_Click(object sender, EventArgs e)
        {
            _currentTool = "Eraser";
        }

        private void ColorPickerButton_Click(object sender, EventArgs e)
        {
            if (colorDialog.ShowDialog() == DialogResult.OK)
            {
                _currentColor = colorDialog.Color;
            }
        }

        private void DrawingPanel_MouseDown(object sender, MouseEventArgs e)
        {
            _isDrawing = true;
            _previousPoint = e.Location;
            Draw(e.Location);
        }

        private void DrawingPanel_MouseMove(object sender, MouseEventArgs e)
        {
            if (_isDrawing)
            {
                Draw(e.Location);
                _previousPoint = e.Location;
            }
        }

        private void DrawingPanel_MouseUp(object sender, MouseEventArgs e)
        {
            _isDrawing = false;
        }

        private void Draw(Point point)
        {
            using (Graphics g = Graphics.FromImage(_canvasBitmap))
            {
                if (_currentTool == "Pencil")
                {
                    using (Pen pen = new Pen(_currentColor, 10))
                    {
                        g.DrawLine(pen, _previousPoint, point);
                    }
                }
                else if (_currentTool == "Eraser")
                {
                    using (Pen pen = new Pen(Color.White, 10))
                    {
                        g.DrawLine(pen, _previousPoint, point);
                    }
                }
            }
            drawingPanel.Invalidate(); // Trigger a repaint to update the panel
        }

        private void DrawingPanel_Paint(object sender, PaintEventArgs e)
        {
            e.Graphics.DrawImageUnscaled(_canvasBitmap, Point.Empty);
        }

        private void SaveButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "PNG Files (*.png)|*.png"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                _canvasBitmap.Save(saveFileDialog.FileName, ImageFormat.Png);
            }
        }

        private void LoadButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "PNG Files (*.png)|*.png"
            };

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (var bmpTemp = new Bitmap(openFileDialog.FileName))
                {
                    _canvasBitmap = new Bitmap(bmpTemp);
                }
                drawingPanel.BackgroundImage = _canvasBitmap;
                drawingPanel.Invalidate(); // Trigger a repaint to update the panel
            }
        }

        private void ExportButton_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog
            {
                Filter = "PNG Files (*.png)|*.png"
            };

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                _canvasBitmap.Save(saveFileDialog.FileName, ImageFormat.Png);
            }
        }
    }
}
